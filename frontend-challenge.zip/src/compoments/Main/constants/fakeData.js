exports.FAKEDATA = [
  {
    id: 'SP016010220000',
    title: '2149: The Aftermath',
    genres: ['Action', 'Thriller'],
  },
  { id: 'SP015893830000', title: '616 Wilford Lane', genres: ['Crime drama'] },
  {
    id: 'SP012496520000',
    title: 'Above Suspicion',
    genres: ['Crime drama', 'Mystery'],
  },
  {
    id: 'SP012813800000',
    title: 'American Fighter',
    genres: ['Children', 'Comedy', 'Adventure', 'Animated'],
  },
  { id: 'SP015653500000', title: 'Boogie', genres: ['Drama'] },
  { id: 'SP014459640000', title: 'French Exit', genres: ['Action'] },
  {
    id: 'SP013301360000',
    title: 'Georgetown',
    genres: ['Crime drama', 'Thriller'],
  },
  {
    id: 'SP016143620000',
    title: 'High Ground',
    genres: ['Historical drama', 'Biography'],
  },
  {
    id: 'SP015766610000',
    title: 'In the Earth',
    genres: ['Action', 'Thriller', 'Dark comedy'],
  },
  {
    id: 'SP014367840000',
    title: 'Judas and the Black Messiah',
    genres: ['Action', 'Crime drama', 'Dark comedy'],
  },
  {
    id: 'SP015806650000',
    title: 'Justice Society: World War II',
    genres: ['Children', 'Adventure', 'Animated'],
  },
];
