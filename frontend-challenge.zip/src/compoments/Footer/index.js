import React from "react";
import "../../styles.css";

const Footer = () => {
  return <h3 className="footer">&copy; 2021-02-20 John Chang</h3>;
};

export default Footer;
