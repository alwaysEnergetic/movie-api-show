import React from "react";
import "../../styles.css";

const Header = () => {
  return <h1>Front-End Code Challenge</h1>;
};

export default Header;
